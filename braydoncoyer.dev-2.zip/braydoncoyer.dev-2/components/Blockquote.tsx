export function Blockquote({ children }) {
  return <blockquote className="p-3 rounded-r-lg">{children}</blockquote>;
}
