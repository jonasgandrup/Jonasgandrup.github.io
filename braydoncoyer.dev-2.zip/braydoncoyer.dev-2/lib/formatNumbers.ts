export let internationalNumberFormat = new Intl.NumberFormat('en-US');
