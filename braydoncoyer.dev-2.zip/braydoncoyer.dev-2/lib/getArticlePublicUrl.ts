export function getArticlePublicUrl(slug: string) {
  return `https://braydoncoyer.dev/blog/${slug}`;
}
